/**
 * Created by anindcha on 6/18/2016.
 */
helloApp.controller('gravatarController',
    function garavatarController($scope, gravatarUrlBuilder){
        $scope.user={};
        $scope.getGravatarUrl= function(email){
            return gravatarUrlBuilder(email);
        };

    }

);