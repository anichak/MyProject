/**
 * Created by anindcha on 6/13/2016.
 */
helloApp.controller('bookList',function($scope,blogService){
    $scope.sortOrder="-vote";
    $scope.count=function (blog) {
        blog.vote++;
    }
    var callback=function (data) {
        $scope.blogs=data;
    }
   blogService(callback);
});