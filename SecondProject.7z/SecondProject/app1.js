/**
 * Created by anindcha on 6/13/2016.
 */
var helloApp=angular.module('app',[]);