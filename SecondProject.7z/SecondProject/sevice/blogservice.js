/**
 * Created by anindcha on 6/16/2016.
 */
helloApp.factory("blogService",function($http){
   return function(cb){ 
       $http({
        method : "GET",
        url : "data/blog.json"
    }).then(function (response) {
           console.log(response);
        cb(response.data);
    }, function (response) {
         console.log(response);
    });
       console.log("Service ended");
   }
});