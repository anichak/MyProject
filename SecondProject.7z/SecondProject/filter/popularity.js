/**
 * Created by anindcha on 6/15/2016.
 */
helloApp.filter("popularity",function(){
   var max=0;
    return function(arr,value){
        value=parseInt(value);
        if(value>max){
            max=value;
        }
        value=Math.round((5*value)/max);
        for(var i=0;i<value;i++){
            arr.push(i);
        }
        return arr;
    }
});