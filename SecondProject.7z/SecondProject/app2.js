/**
 * Created by anindcha on 6/18/2016.
 */
var helloApp= angular.module('app', ['ngResource', 'ngRoute'])
    .config(function($routeProvider){
        $routeProvider.when('/home',{

            templateUrl:'templates/displayBlogs.html',
            controller: 'bookList'

        });

        $routeProvider.when('/addNew',{

            templateUrl:'templates/addBlogs.html',
            controller: 'gravatarController'
        });

        $routeProvider.otherwise({redirectTo:'/home'});

        console.log('App called.');
    });